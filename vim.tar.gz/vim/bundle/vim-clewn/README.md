vim-clewn
=========

Clewm: VIM GDB connector (http://clewn.sourceforge.net/)

This is the vim-specific parts of clewn.
