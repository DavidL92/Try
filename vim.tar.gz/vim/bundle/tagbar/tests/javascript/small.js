var app = {
    foo: function(){},
    bar: function(){}
}

var dsads = {
    fdfsd: function(){},
    dsadas: function(){}
}
