namespace Parser
{
  namespace XXX
  {
    class Foobar
    {
      class Blah
      {
        class Bar
        {
          class Lalala
          {
          public:
            Foobar();
          }
        }
      }

    };
  };
};

void*
Parser::XXX::Foobar::wait(int i, const char const * const * p)
{
  return;
}

void
Foobar::non_nil()
{
  return;
}
