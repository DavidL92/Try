void*
Foo::bar(int i,
         const char const * const * p)
{
  return;
}
