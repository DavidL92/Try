int animal::moose::getFeet() //^2^
{
  return fFeet;
}

void animal::moose::doNothing() //^3^
{
  animal::moose foo();

  fFeet = N// -15-
    ; // #15# ( "NAME1" "NAME2" "NAME3" )
}
