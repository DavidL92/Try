class Foo
    def a
    end

    def b
    end

    def Foo.c(item)
    end

    def self.d
    end
end
