class Class2
  def self.fun1()
    value=if foo
            bar
          end
  end

  def self.fun2()
  end
end
