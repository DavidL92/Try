#!/usr/bin/env python

class ClassName(object):
    """docstring for ClassName"""
    def __init__(self, arg):
        super(ClassName, self).__init__()
        self.arg = arg
    def function1(self):
        foo = """
foostring
    """
    def function2(self):
        pass
