def foo(a, b, \
        c, d):
    pass
