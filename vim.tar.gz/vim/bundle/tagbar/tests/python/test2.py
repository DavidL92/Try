from test import *

r = test.Inner()
